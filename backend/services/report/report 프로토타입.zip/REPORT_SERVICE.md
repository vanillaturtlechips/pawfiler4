# Report Service 팀 공유 문서

## 개요

사용자의 퀴즈 풀이 데이터를 분석해 개인 맞춤형 HTML 리포트를 생성하는 서비스입니다.
현재는 동기 방식으로 동작하며, 향후 Redis + Celery 비동기 큐 방식으로 전환을 검토 중입니다.

---

## 현재 아키텍처 (동기 방식)

```
클라이언트
    │
    ▼
POST /generate
    │  (DB 쿼리 + 이미지 생성 + HTML 빌드 — 동기 처리)
    ▼
GET /download/{user_id}
    │  (로컬 파일 반환)
    ▼
클라이언트에 HTML 파일 전달
```

요청이 들어오면 DB 쿼리 → 차트/이미지 생성 → HTML 빌드까지 한 번에 처리하고 응답합니다.
처리 시간이 길어질 경우 타임아웃 위험이 있어 비동기 전환을 권장합니다.

---

## 목표 아키텍처 (비동기 큐 방식)

```
클라이언트
    │
    ▼
POST /generate
    │  job_id 즉시 반환
    ▼
Redis 큐에 작업 등록
    │
    ▼
Celery Worker (백그라운드)
    │  DB 쿼리 + 이미지 생성 + HTML 빌드
    ▼
완료 시 S3에 HTML 저장
    │
    ▼
GET /status/{job_id}   → pending / done / error 확인
GET /download/{job_id} → S3 presigned URL로 리다이렉트
```

---

## EKS 내부 동작 방식

### 전체 흐름

```
인터넷
  │
  ▼
ALB (Application Load Balancer)
  │  HTTPS 443 → HTTP 8090
  ▼
Ingress (AWS Load Balancer Controller)
  │
  ▼
report-service (ClusterIP :8090)
  │
  ▼
report-service Pod (FastAPI + uvicorn, workers=4)
  │
  ├── PostgreSQL (RDS) — 퀴즈 풀이 데이터 조회
  └── /tmp 로컬 파일시스템 — 생성된 HTML 임시 저장
```

### Pod 구성

| 항목                 | 값                                                                                 |
| -------------------- | ---------------------------------------------------------------------------------- |
| 이미지               | `009946608368.dkr.ecr.ap-northeast-2.amazonaws.com/pawfiler/report-service:latest` |
| 포트                 | 8090 (HTTP)                                                                        |
| 최소 replicas        | 1                                                                                  |
| 최대 replicas        | 5                                                                                  |
| CPU request/limit    | 250m / 1000m                                                                       |
| Memory request/limit | 384Mi / 768Mi                                                                      |
| uvicorn workers      | 4                                                                                  |

### HPA (Auto Scaling) 조건

- CPU 사용률 65% 초과 시 스케일 아웃
- Memory 사용률 75% 초과 시 스케일 아웃
- 최소 1개 ~ 최대 5개 Pod 유지

### 시크릿 관리

DB 접속 정보는 Kubernetes Secret `db-credentials`에서 주입됩니다.
External Secrets Operator가 AWS Secrets Manager에서 자동으로 동기화합니다.

```yaml
env:
  - name: DATABASE_URL
    valueFrom:
      secretKeyRef:
        name: db-credentials
        key: report-db-url
```

---

## 배포 흐름 (GitOps)

```
코드 변경 (main 브랜치 push)
    │
    ▼
GitHub Actions
    │  docker build → ECR push (tag: latest)
    ▼
ECR (009946608368.dkr.ecr.ap-northeast-2.amazonaws.com/pawfiler/report-service)
    │
    ▼
ArgoCD (pawfiler4-argocd 레포 감시)
    │  apps/services/report/ 변경 감지
    ▼
EKS에 자동 배포 (selfHeal: true, prune: true)
    │
    ▼
report-service Pod 롤링 업데이트
```

ArgoCD ApplicationSet이 `apps/services/*` 디렉토리를 자동 감지하므로
`pawfiler4-argocd` 레포의 `apps/services/report/` 내용을 수정하면 자동 반영됩니다.

---

## API 엔드포인트

| Method | Path                  | 설명                        |
| ------ | --------------------- | --------------------------- |
| POST   | `/generate`           | 리포트 생성 요청            |
| GET    | `/download/{user_id}` | 생성된 HTML 리포트 다운로드 |
| GET    | `/health`             | 헬스체크                    |

### POST /generate 요청 예시

```json
{
  "user_id": "user-123",
  "days": 30,
  "nickname": "탐정홍길동",
  "avatar_emoji": "🐾",
  "email": "user@example.com",
  "subscription_type": "premium"
}
```

### 응답

```json
{
  "report_url": "/download/user-123"
}
```

---

## 리포트 생성 내부 로직

```
fetch_user_report_data(user_id, days)
    │  PostgreSQL에서 아래 데이터 조회
    │  - stats: 전체 정답률, 총 풀이 수, 총 XP
    │  - type_stats: 퀴즈 타입 × 난이도별 통계
    │  - weekly: 주간 정답률 추이
    │  - wrong_answers: 최근 틀린 문제 5개 (오답노트용)
    │  - weak_labels: 취약 단서 TOP3 (region_select 오답 집계)
    │  - profile: 티어, 코인, 경험치, 아바타
    ▼
build_html(...)
    │  구성 요소별 생성
    ├── make_avatar()              — 아바타 HTML/CSS 렌더링 (이모지 기반)
    ├── make_chart()               — 주간 정답률 막대 차트 (matplotlib)
    ├── detect_story_patterns()    — 데이터 패턴 분석 (볼륨/성장/연속/취약유형)
    ├── build_story()              — 패턴 기반 3~4문장 성장 스토리 생성 (순수 연산)
    ├── 오답노트 섹션              — 틀린 문제 썸네일 + 정답 + 해설
    └── 취약 단서 TOP3 섹션        — 라벨별 정답률 바 + 집중 훈련 팁
    ▼
HTML 파일 저장 → /reports/{user_id}.html
    ▼
/download/{user_id} 로 응답
```

> 참고: `make_parchment_bg()`, `make_heatmap()`, `make_pawprints()`는 현재 코드에서 제거되었습니다.
> 양피지 배경은 CSS로, 히트맵/발자국은 미사용 상태입니다.

---

## 로컬 개발 환경

```bash
# Docker Compose로 실행
cd pawfiler4/backend
docker-compose up -d report-service

# 직접 실행
cd pawfiler4/backend/services/report
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8090 --reload

# 리포트 생성 테스트
curl -X POST http://localhost:8090/generate \
  -H "Content-Type: application/json" \
  -d '{"user_id": "test-user", "days": 30}'
```

---

## 운영 가이드

### 모니터링 포인트

- `/health` 엔드포인트 — liveness/readiness probe가 15~30초 간격으로 체크
- CPU 65% / Memory 75% 도달 시 HPA가 자동 스케일 아웃
- 리포트 생성 실패 시 500 에러 + 상세 메시지 반환

### 주의사항

1. `/tmp` 파일시스템 — Pod 재시작 시 생성된 HTML 파일이 사라집니다. 현재는 재생성 요청 필요.
2. 이미지 생성(`make_chart()`, matplotlib)이 CPU를 많이 씁니다. 동시 요청이 몰리면 HPA 스케일 아웃 확인하세요.
   - 성장 스토리(`detect_story_patterns`, `build_story`)는 순수 Python 연산으로 CPU 부담 없음.
3. `latest` 태그 사용 중 — 운영 안정화 후 버전 태그(예: `v1.0.0`) 전환을 권장합니다.

### 장애 대응

```bash
# Pod 상태 확인
kubectl get pods -n pawfiler -l app=report-service

# 로그 확인
kubectl logs -n pawfiler -l app=report-service --tail=100

# Pod 재시작
kubectl rollout restart deployment/report-service -n pawfiler

# HPA 상태 확인
kubectl get hpa report-service -n pawfiler
```

---

## 향후 개선 계획

| 우선순위 | 항목                       | 이유                               |
| -------- | -------------------------- | ---------------------------------- |
| 높음     | Redis + Celery 비동기 전환 | 동기 처리 타임아웃 위험 제거       |
| 높음     | S3 저장 + presigned URL    | Pod 재시작 시 파일 유실 방지       |
| 중간     | 버전 태그 배포             | `latest` 태그는 롤백이 어려움      |
| 낮음     | 리포트 캐싱                | 동일 user_id 재요청 시 재생성 방지 |
